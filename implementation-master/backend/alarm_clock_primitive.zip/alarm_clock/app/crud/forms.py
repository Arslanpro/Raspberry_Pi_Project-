from wtforms import StringField, SelectField, SubmitField, IntegerField
from wtforms.validators import DataRequired, Length, Email, Regexp
from wtforms import ValidationError
from alarm_clock.app.crud.models import Person
from flask_wtf import Form


class AddPersonForm(Form):
    name = StringField('name')
    age = IntegerField('age')
    gender = StringField('gender')
    submit = SubmitField('save')


class EditPersonForm(Form):
    name = StringField('name')
    age = IntegerField('age')
    gender = StringField('gender')
    submit = SubmitField('update')

