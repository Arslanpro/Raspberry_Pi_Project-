from flask import request, render_template, Blueprint, flash, redirect, url_for

from .forms import *
from flask import Blueprint
from .controllers import *

crud = Blueprint('crud', __name__, template_folder="templates", static_url_path='',
                 static_folder='templates/static')


@crud.route('/')
def index():
    personservice  = PersonDao()
    persons = personservice.list_all()
    return render_template('index.html', persons=persons)


@crud.route('/new', methods=['GET', 'POST'])
def new_person():
    form = AddPersonForm()

    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        gender = request.form['gender']
        personservice = PersonDao()
        personservice.create_person(name, age, gender)

        return redirect(url_for('person.index'))

    return render_template('person.html', form=form)


@crud.route('/edit/<int:user_id>', methods=['GET', 'POST'])
def edit_note(user_id):
    form = EditPersonForm()
    person = PersonDao().get_person(user_id)
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        gender = request.form['gender']
        person.age = age
        person.name = name
        person.gender = gender
        PersonDao.update_person(person)
        return redirect(url_for('person.index'))

    form.name.data = person.name
    form.gender.data = person.gender
    form.age.data = person.gender
    return render_template('edit_person.html', form=form)


@crud.route('/delete/<int:user_id>', methods=['GET'])
def delete_note(user_id):
    personservice = PersonDao()
    person = personservice.get_person(user_id)
    personservice.delete_person(person)

    return redirect(url_for('person.index'))