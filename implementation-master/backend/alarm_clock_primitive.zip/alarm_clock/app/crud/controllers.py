from sqlalchemy import desc

from .models import db
from alarm_clock.app.crud.models import Person


class PersonDao():

    def create_person(self, new_name, new_age, new_gender):
        new_person = Person(name=new_name, age=new_age, gender=new_gender)
        db.session.add(new_person)
        db.session.commit()
        return new_person

    def update_person(self, person):
        modified_person = Person.query.get(person.uid)
        db.session.commit()

        return modified_person

    def delete_person(self, person):
        person_to_delete = Person.query.get(person.uid)
        db.session.delete(person_to_delete)
        db.session.commit

        return person_to_delete

    def list_all(self):
        return Person.query.order_by(desc(Person.uid)).all()

    def get_person(self, uid):
        return Person.query.get(uid)
