from alarm_clock.app.crud.models import db
from alarm_clock.app import create_app

app = create_app()
db.app = app
db.init_app(app)

if __name__ == '__main__':
    db.drop_all()
    db.create_all()
    print ('Done')