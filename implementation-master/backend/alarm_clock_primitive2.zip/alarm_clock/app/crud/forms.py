from wtforms import StringField, SelectField, SubmitField, IntegerField, DateTimeField
from wtforms.validators import DataRequired, Length, Email, Regexp
from wtforms import ValidationError
from alarm_clock.app.crud.models import Person
from flask_wtf import Form


class AddPersonForm(Form):
    name = StringField('name')
    age = IntegerField('age')
    gender = StringField('gender')
    submit = SubmitField('save')


class EditPersonForm(Form):
    name = StringField('name')
    age = IntegerField('age')
    gender = StringField('gender')
    submit = SubmitField('update')


class AddAlarmForm(Form):
    current_time = DateTimeField('current_time')
    alarm_time = DateTimeField('alarm_time')
    time_range = IntegerField('time_range')
    snooze_time = IntegerField('snooze_time')
    current_date = DateTimeField('current_date')
    auid = IntegerField('auid')
    submit = SubmitField('save')


class EditAlarmForm(Form):
    current_time = DateTimeField('current_time')
    alarm_time = DateTimeField('alarm_time')
    time_range = IntegerField('time_range')
    snooze_time = IntegerField('snooze_time')
    current_date = DateTimeField('current_date')
    auid = IntegerField('auid')
    submit = SubmitField('update')

class AddCollectionForm(Form):
    move_detection = IntegerField('move_detection')
    collected_time = DateTimeField('collected_time')
    caid = IntegerField('caid')
    submit = SubmitField('save')

class EditCollectionForm(Form):
    move_detection = IntegerField('move_detection')
    collected_time = DateTimeField('collected_time')
    caid = IntegerField('caid')
    submit = SubmitField('update')
