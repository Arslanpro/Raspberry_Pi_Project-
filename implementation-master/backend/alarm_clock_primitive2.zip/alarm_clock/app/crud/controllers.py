from sqlalchemy import desc

from .models import db
from alarm_clock.app.crud.models import Person, Alarm, Collection


class PersonDao():

    def create_person(self, new_name, new_age, new_gender):
        new_person = Person(name=new_name, age=new_age, gender=new_gender)
        db.session.add(new_person)
        db.session.commit()
        return new_person

    def update_person(self, person):
        modified_person = Person.query.get(person.uid)
        db.session.commit()

        return modified_person

    def delete_person(self, person):
        person_to_delete = Person.query.get(person.uid)
        db.session.delete(person_to_delete)
        db.session.commit()

        return person_to_delete

    def list_all(self):
        return Person.query.order_by(desc(Person.uid)).all()

    def get_person(self, uid):
        return Person.query.get(uid)


class AlarmDao():

    def create_Alarm(self, current_time, alarm_time, time_range, snooze_time, current_date, auid):
        new_alarm = Alarm(current_time=current_time, alarm_time=alarm_time, time_range=time_range,
                          snooze_time=snooze_time, current_date=current_date, auid=auid)
        db.session.add(new_alarm)
        db.session.commit()
        return new_alarm

    def update_alarm(self, alarm):
        modified_alarm = Alarm.query.get(alarm.aid)
        db.session.commit()

        return modified_alarm

    def delete_alarm(self, alarm):
        alarm_to_delete = Alarm.query.get(alarm.aid)
        db.session.delete(alarm_to_delete)
        db.session.commit()

        return alarm_to_delete

    def list_all(self):
        return Alarm.query.order_by(desc(Alarm.aid)).all()

    def get_alarm(self, aid):
        return Alarm.query.get(aid)

    def user_alarm(self, uid):
        pass


class CollectionDao():

    def create_collection(self, move_detection, collected_time, caid):
        new_collection = Collection(move_detection=move_detection, collected_time=collected_time, caid=caid)
        db.session.add(new_collection)
        db.session.commit()
        return new_collection

    def update_collection(self, collection):
        modified_collection = Collection.query.get(collection.cid)
        db.session.commit()

        return modified_collection

    def delete_collection(self, collection):
        collection_to_delete = Collection.query.get(collection.cid)
        db.session.delete(collection_to_delete)
        db.session.commit()

        return collection_to_delete

    def list_all(self):
        return Collection.query.order_by(desc(Collection.cid)).all()

    def get_collection(self, cid):
        return Collection.query.get(cid)

    def list_one_day(self, date):
        pass

